package com.mts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mts.model.Screen;



public interface ScreenRepository extends JpaRepository<Screen, Integer> {

}
