package com.mts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mts.model.Theatre;

public interface TheatreRepository extends JpaRepository<Theatre, Integer> {

}
