export class User {
  public userid: number;
  public username: string;
  public password: string;
  public role: string;
}
