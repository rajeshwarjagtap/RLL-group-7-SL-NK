import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-view-customer',
  templateUrl: './detail-view-customer.component.html',
  styleUrls: ['./detail-view-customer.component.css']
})
export class DetailViewCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
